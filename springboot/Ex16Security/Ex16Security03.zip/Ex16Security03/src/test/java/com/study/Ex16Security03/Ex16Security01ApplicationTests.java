package com.study.Ex16Security03;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ex16Security01ApplicationTests {

	@Test
	void contextLoads() {
	}

}
